
export enum LogStatus {
  OPEN = 'OPEN',
  OK = 'OK',
  DISCREPANCY = 'DISCREPANCY',
  PENDING = 'PENDING'
}

export interface DailyLog {
  id: string;
  date: string;
  dayName: string;
  time: string;
  location: string;
  status: LogStatus;
  busId: string;
  driverId: string;
  diesel: number;
  adBlue: number;
  oil: number | null;
}

export interface MonthlyStats {
  diesel: number;
  adBlue: number;
  openTasks: number;
}
