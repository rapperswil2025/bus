
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const RegisterScreen: React.FC = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/dashboard');
  };

  return (
    <div className="flex h-full min-h-screen w-full flex-col bg-background-light dark:bg-background-dark text-[#111418] dark:text-white">
      <div className="relative w-full shrink-0">
        <div 
          className="w-full h-48 bg-center bg-cover relative" 
          style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDa-NqoZG8Ix7ZvxYmeSqhgGylzCe7JCcbSuSdzpyDdmjI_fqFgda2IEVxRD7Tap4qR_CTTDUdh_NP0xs7OCJ3O7L5O6aeAfwXLl4POuNCpCaOfyS0Pa9C_zneXWYVtQMfslEPVkbasbm506WmQ_-D7L-gVvttBv2x93y_fAq0oYZ-t3hd1HbwBB6-gelu2Mx9Egg5-HJCCQHd2kpGovDwkqAsWIdQWcIKc_FF-5R6t_iELkTPpCGnWPzre_2WZeqND-K64G-rqKWY")' }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-background-light dark:to-background-dark" />
          <div className="absolute inset-0 flex flex-col items-center justify-center pt-4">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl flex items-center gap-3 shadow-lg">
              <div className="bg-primary text-white p-2 rounded-lg flex items-center justify-center">
                <span className="material-symbols-outlined text-2xl">directions_bus</span>
              </div>
              <h1 className="text-white text-xl font-bold tracking-wide">AHW Busbetriebe</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 px-5 -mt-6 relative z-10 pb-8">
        <div className="bg-white dark:bg-[#1c2127] rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-[#3b4754] mb-6">
          <h2 className="text-2xl font-bold text-center mb-1 text-gray-900 dark:text-white">Fahrer-Registrierung</h2>
          <p className="text-center text-sm text-gray-500 dark:text-[#9dabb9]">Erstellen Sie Ihren Account für den Fahrbetrieb</p>
        </div>

        <form className="flex flex-col gap-5" onSubmit={handleRegister}>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-200 ml-1">Fahrernummer</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-gray-400 dark:text-[#9dabb9]">badge</span>
              </div>
              <input 
                className="block w-full pl-10 pr-3 h-12 rounded-xl border border-gray-200 dark:border-[#3b4754] bg-white dark:bg-[#1c2127] text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-[#9dabb9] focus:border-primary focus:ring-primary focus:ring-1 text-sm transition-colors" 
                placeholder="z.B. 1045" 
                type="number"
                required
              />
            </div>
          </div>

          <div className="flex flex-row gap-4">
            <div className="space-y-2 flex-1 min-w-0">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-200 ml-1">Vorname</label>
              <input 
                className="block w-full h-12 rounded-xl border border-gray-200 dark:border-[#3b4754] bg-white dark:bg-[#1c2127] text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-[#9dabb9] focus:border-primary focus:ring-primary focus:ring-1 text-sm transition-colors" 
                placeholder="Max" 
                type="text"
                required
              />
            </div>
            <div className="space-y-2 flex-1 min-w-0">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-200 ml-1">Nachname</label>
              <input 
                className="block w-full h-12 rounded-xl border border-gray-200 dark:border-[#3b4754] bg-white dark:bg-[#1c2127] text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-[#9dabb9] focus:border-primary focus:ring-primary focus:ring-1 text-sm transition-colors" 
                placeholder="Mustermann" 
                type="text"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-200 ml-1">Passwort</label>
            <div className="relative">
              <input 
                className="block w-full h-12 pr-10 rounded-xl border border-gray-200 dark:border-[#3b4754] bg-white dark:bg-[#1c2127] text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-[#9dabb9] focus:border-primary focus:ring-primary focus:ring-1 text-sm transition-colors" 
                placeholder="••••••••" 
                type={showPassword ? "text" : "password"}
                required
              />
              <div 
                className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer hover:text-primary transition-colors text-gray-400 dark:text-[#9dabb9]"
                onClick={() => setShowPassword(!showPassword)}
              >
                <span className="material-symbols-outlined text-[20px]">{showPassword ? 'visibility_off' : 'visibility'}</span>
              </div>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-primary hover:bg-blue-600 text-white font-bold h-14 rounded-xl shadow-lg shadow-primary/30 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 mt-4"
          >
            <span>Registrierung abschließen</span>
            <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
          </button>

          <div className="text-center mt-2">
            <Link to="/" className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary transition-colors">
              <span className="material-symbols-outlined text-[18px]">arrow_back</span>
              <span>Bereits Account? Zum Login</span>
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegisterScreen;
