
import React, { useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';

const LogEntryScreen: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [showToast, setShowToast] = useState(false);
  const [formData, setFormData] = useState({
    busId: isEdit ? '750' : '750',
    month: '2023-10',
    driverId: '10245',
    firstName: 'Hans',
    lastName: 'Müller',
    date: '2023-10-24',
    diesel: '',
    oil: '',
    adBlue: '',
    notes: ''
  });

  const handleSave = () => {
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white antialiased relative min-h-screen flex flex-col">
      {/* Toast Notification */}
      {showToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 animate-toast pointer-events-none w-max max-w-[90vw]">
          <div className="bg-surface-dark text-white dark:bg-white dark:text-slate-900 px-6 py-3.5 rounded-full shadow-2xl flex items-center gap-3 border border-white/10 dark:border-slate-200 backdrop-blur-md">
            <span className="material-symbols-outlined text-green-500 text-[1.5rem]">check_circle</span>
            <div>
              <p className="font-bold text-sm leading-tight">Gespeichert</p>
              <p className="text-xs opacity-80 leading-tight">Daten erfolgreich übertragen</p>
            </div>
          </div>
        </div>
      )}

      <header className="sticky top-0 z-20 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-gray-200 dark:border-border-dark">
        <div className="flex items-center justify-between px-4 py-3">
          <Link to="/dashboard" className="flex size-10 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
            <span className="material-symbols-outlined text-slate-900 dark:text-white text-2xl">arrow_back</span>
          </Link>
          <div className="flex-1 flex justify-center">
            <div className="relative group">
              <select 
                value={`#BUS ${formData.busId}`}
                onChange={(e) => setFormData({...formData, busId: e.target.value.replace('#BUS ', '')})}
                className="appearance-none bg-primary text-xl font-bold text-white py-3 pr-12 pl-6 text-center leading-tight focus:outline-none cursor-pointer border-[3px] border-white/30 hover:bg-blue-600 focus:ring-4 focus:ring-primary/40 rounded-full shadow-xl shadow-primary/40 transition-all tracking-wide"
              >
                <option>#BUS 750</option>
                <option>#BUS 751</option>
                <option>#BUS 752</option>
                <option>#BUS 753</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-white">
                <span className="material-symbols-outlined text-2xl drop-shadow-sm">expand_more</span>
              </div>
            </div>
          </div>
          <button className="flex size-10 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
            <span className="material-symbols-outlined text-slate-900 dark:text-white text-2xl">history</span>
          </button>
        </div>
        
        <div className="px-4 pb-4 pt-1">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-white text-lg">directions_bus</span>
                </div>
                <div>
                  <p className="text-text-secondary text-[10px] font-bold uppercase tracking-wider">Aktuelles Log</p>
                  <h2 className="text-xl font-bold tracking-tight">Okt 2023 · Freienbach</h2>
                </div>
              </div>
            </div>
            <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center self-end mb-1">
              <span className="material-symbols-outlined text-primary">analytics</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-32 px-4 pt-6 space-y-8">
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <span className="material-symbols-outlined text-xl">calendar_month</span>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary">Berichtsmonat</h3>
          </div>
          <div className="bg-white dark:bg-surface-dark rounded-xl p-2 border border-gray-200 dark:border-border-dark shadow-sm">
            <div className="relative">
              <select 
                value={formData.month}
                onChange={(e) => setFormData({...formData, month: e.target.value})}
                className="w-full appearance-none rounded-lg bg-gray-50 dark:bg-[#11161b] py-3 pl-4 pr-10 text-base font-bold text-slate-900 dark:text-white border border-gray-200 dark:border-border-dark focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
              >
                <option value="2023-10">Oktober 2023</option>
                <option value="2023-09">September 2023</option>
                <option value="2023-08">August 2023</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                <span className="material-symbols-outlined">expand_more</span>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-2 text-primary">
            <span className="material-symbols-outlined text-xl">badge</span>
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary">Fahrerdaten</h3>
          </div>
          <div className="bg-white dark:bg-surface-dark rounded-xl p-4 border border-gray-200 dark:border-border-dark shadow-sm">
            <div className="space-y-4">
              <label className="block">
                <span className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Fahrernummer</span>
                <input 
                  className="w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] text-slate-900 dark:text-white focus:border-primary focus:ring-primary h-12 px-4 font-medium" 
                  placeholder="z.B. 8824" 
                  type="text" 
                  value={formData.driverId}
                  onChange={(e) => setFormData({...formData, driverId: e.target.value})}
                />
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="block">
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Vorname</span>
                  <input 
                    className="w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] text-slate-900 dark:text-white focus:border-primary focus:ring-primary h-12 px-4" 
                    type="text" 
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  />
                </label>
                <label className="block">
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Nachname</span>
                  <input 
                    className="w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] text-slate-900 dark:text-white focus:border-primary focus:ring-primary h-12 px-4" 
                    type="text" 
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  />
                </label>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary">
              <span className="material-symbols-outlined text-xl">local_gas_station</span>
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-text-secondary">Tageserfassung</h3>
            </div>
            <div className="relative">
              <input 
                className="absolute inset-0 opacity-0 w-full h-full z-10 cursor-pointer" 
                type="date" 
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
              />
              <div className="flex items-center gap-2 bg-primary/10 px-3 py-1.5 rounded-lg border border-primary/20 cursor-pointer">
                <span className="material-symbols-outlined text-primary text-sm">calendar_today</span>
                <span className="text-xs font-bold text-primary">Heute, 24. Okt</span>
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-surface-dark rounded-xl p-5 border border-gray-200 dark:border-border-dark shadow-sm space-y-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-amber-500 dark:text-amber-400">
                <span className="material-symbols-outlined">local_gas_station</span>
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1 block">Diesel</label>
                <div className="relative">
                  <input 
                    className="peer w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] p-3 pr-10 text-lg font-bold text-slate-900 dark:text-white placeholder-slate-400 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                    inputMode="decimal" 
                    placeholder="0.0" 
                    type="number"
                    value={formData.diesel}
                    onChange={(e) => setFormData({...formData, diesel: e.target.value})}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 peer-focus:text-primary transition-colors">L</span>
                </div>
              </div>
            </div>

            <div className="h-px w-full bg-gray-100 dark:bg-border-dark" />

            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-purple-500/20 text-purple-600 dark:text-purple-400">
                <span className="material-symbols-outlined">oil_barrel</span>
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1 block">Motoröl</label>
                <div className="relative">
                  <input 
                    className="peer w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] p-3 pr-10 text-lg font-bold text-slate-900 dark:text-white placeholder-slate-400 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                    inputMode="decimal" 
                    placeholder="0.0" 
                    type="number"
                    value={formData.oil}
                    onChange={(e) => setFormData({...formData, oil: e.target.value})}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 peer-focus:text-primary transition-colors">L</span>
                </div>
              </div>
            </div>

            <div className="h-px w-full bg-gray-100 dark:bg-border-dark" />

            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-600 dark:text-cyan-400">
                <span className="material-symbols-outlined">water_drop</span>
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1 block">AdBlue</label>
                <div className="relative">
                  <input 
                    className="peer w-full rounded-lg border-gray-300 dark:border-border-dark bg-gray-50 dark:bg-[#11161b] p-3 pr-10 text-lg font-bold text-slate-900 dark:text-white placeholder-slate-400 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                    inputMode="decimal" 
                    placeholder="0.0" 
                    type="number"
                    value={formData.adBlue}
                    onChange={(e) => setFormData({...formData, adBlue: e.target.value})}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 peer-focus:text-primary transition-colors">L</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-2">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 px-1">Bemerkungen</label>
          <textarea 
            className="w-full rounded-lg border border-gray-300 dark:border-border-dark bg-white dark:bg-surface-dark p-3 text-slate-900 dark:text-white focus:border-primary focus:ring-primary h-24 resize-none" 
            placeholder="Probleme mit dem Fahrzeug, Verspätungen, etc..."
            value={formData.notes}
            onChange={(e) => setFormData({...formData, notes: e.target.value})}
          />
        </section>
      </main>

      <div className="fixed bottom-0 left-0 right-0 z-20 w-full bg-background-light dark:bg-background-dark p-4 border-t border-gray-200 dark:border-border-dark max-w-md mx-auto">
        <button 
          onClick={handleSave}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 text-base font-bold text-white shadow-lg shadow-primary/25 hover:bg-blue-600 active:scale-[0.98] transition-all cursor-pointer select-none"
        >
          <span className="material-symbols-outlined text-xl">save</span>
          <span>Speichern</span>
        </button>
      </div>
    </div>
  );
};

export default LogEntryScreen;
