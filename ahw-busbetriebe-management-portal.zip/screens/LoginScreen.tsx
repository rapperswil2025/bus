
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const LoginScreen: React.FC = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      navigate('/dashboard');
    }, 800);
  };

  return (
    <div className="flex h-full min-h-screen w-full flex-col bg-background-light dark:bg-background-dark overflow-x-hidden">
      <div className="relative w-full h-[280px] shrink-0">
        <div 
          className="absolute inset-0 bg-center bg-no-repeat bg-cover" 
          style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuC1pNkr7asRXqD6zmHLwTlGoQM55SCknCnOT2hDXhIEJWsXGw4RSas3GY13F2hQJ5wiXbz1da7QcX-kQ4TFwTiwAh70H86WXVpfg3RyHAu2o3zXuNCsSC3ovbTwc8j2jY2Iua2WNbu1_EuKRrpofLTTDyeB_Lrkh2jbjwpz8J41sQ5iP9LtcQCiEGYlaKJlurHISOLJ4TTTnqznLUGGWK2M3DriyToN_2fSH9mR0iq27n8JN1UF-6wCdxFLGXGzsrJs6cmUC_jvV6s")' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-background-dark/60 to-background-dark" />
        <div className="absolute bottom-0 left-0 w-full p-6 flex flex-col justify-end">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
              <span className="material-symbols-outlined text-white text-[28px]">directions_bus</span>
            </div>
            <div>
              <p className="text-[10px] font-bold tracking-widest uppercase text-primary/90 mb-0.5">Betriebssystem</p>
              <h2 className="text-lg font-bold text-white leading-none">AHW Busbetriebe</h2>
            </div>
          </div>
          <h1 className="text-white tracking-tight text-[32px] font-bold leading-tight">Fahrer-Anmeldung</h1>
        </div>
      </div>

      <form className="flex flex-col flex-1 px-4 py-6" onSubmit={handleLogin}>
        <div className="mb-6">
          <label className="flex flex-col w-full">
            <p className="text-white text-base font-medium leading-normal pb-2">Fahrernummer</p>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted">
                <span className="material-symbols-outlined text-[20px]">badge</span>
              </span>
              <input 
                className="flex w-full min-w-0 rounded-lg text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-border-dark bg-surface-dark focus:border-primary h-14 placeholder:text-text-muted pl-12 pr-4 text-base font-normal transition-all" 
                inputMode="numeric" 
                pattern="[0-9]*" 
                placeholder="z.B. 12345" 
                type="tel"
                required
              />
            </div>
          </label>
        </div>

        <div className="mb-2">
          <label className="flex flex-col w-full">
            <p className="text-white text-base font-medium leading-normal pb-2">Passwort</p>
            <div className="flex w-full items-stretch rounded-lg relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted z-10">
                <span className="material-symbols-outlined text-[20px]">lock</span>
              </span>
              <input 
                className="flex w-full min-w-0 flex-1 rounded-lg rounded-r-none text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-border-dark bg-surface-dark focus:border-primary h-14 placeholder:text-text-muted pl-12 pr-4 text-base font-normal transition-all border-r-0 z-0" 
                placeholder="******" 
                type={showPassword ? "text" : "password"}
                required
              />
              <button 
                className="text-text-muted flex border border-border-dark bg-surface-dark items-center justify-center px-4 rounded-r-lg border-l-0 hover:text-white transition-colors focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                <span className="material-symbols-outlined text-[24px]">{showPassword ? 'visibility_off' : 'visibility'}</span>
              </button>
            </div>
          </label>
        </div>

        <div className="flex justify-end mb-8">
          <a className="text-primary text-sm font-medium leading-normal py-2 hover:text-primary/80 transition-colors" href="#">
            Passwort vergessen?
          </a>
        </div>

        <div className="mt-auto mb-6">
          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-blue-600 text-white font-bold text-lg h-14 rounded-lg shadow-lg shadow-primary/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-70"
          >
            {loading ? (
              <span className="material-symbols-outlined animate-spin">sync</span>
            ) : (
              <>
                <span>Anmelden</span>
                <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
              </>
            )}
          </button>
          
          <div className="mt-4 flex justify-center w-full">
            <Link 
              to="/register" 
              className="flex items-center gap-2 px-4 py-2 text-text-muted hover:text-white transition-colors rounded-lg hover:bg-surface-dark/50 group"
            >
              <span className="material-symbols-outlined text-[20px] group-hover:text-primary transition-colors">person_add</span>
              <span className="font-medium text-sm">Neuer Fahrer? Registrieren</span>
            </Link>
          </div>

          <div className="mt-4 flex justify-center gap-2">
            <span className="text-text-muted text-sm">Admin Zugang?</span>
            <a className="text-white text-sm font-medium underline decoration-text-muted underline-offset-4 hover:text-primary transition-colors" href="#">Admin-Login</a>
          </div>
        </div>
      </form>
      <div className="h-4 w-full bg-background-dark/50" />
    </div>
  );
};

export default LoginScreen;
