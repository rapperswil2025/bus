
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import StatCard from '../components/StatCard';
import LogCard from '../components/LogCard';
import { DailyLog, LogStatus } from '../types';

const DashboardScreen: React.FC = () => {
  const navigate = useNavigate();
  const [selectedMonth, setSelectedMonth] = useState('oct-2023');

  const logs: DailyLog[] = [
    {
      id: '1',
      date: '12. Okt',
      dayName: 'Di',
      time: '14:30',
      location: 'Einfahrt Nord',
      status: LogStatus.OPEN,
      busId: '402',
      driverId: '99',
      diesel: 120,
      adBlue: 5,
      oil: null
    },
    {
      id: '2',
      date: '12. Okt',
      dayName: 'Di',
      time: '08:15',
      location: 'Halle B',
      status: LogStatus.OK,
      busId: '310',
      driverId: '45',
      diesel: 98,
      adBlue: 0,
      oil: 2
    },
    {
      id: '3',
      date: '11. Okt',
      dayName: 'Mo',
      time: '23:50',
      location: 'Einfahrt Süd',
      status: LogStatus.DISCREPANCY,
      busId: '105',
      driverId: '12',
      diesel: 450,
      adBlue: 10,
      oil: null
    },
    {
      id: '4',
      date: '11. Okt',
      dayName: 'Mo',
      time: '18:10',
      location: 'Halle A',
      status: LogStatus.OK,
      busId: '204',
      driverId: '88',
      diesel: 75,
      adBlue: 2,
      oil: 1
    }
  ];

  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white font-display min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 bg-background-light dark:bg-background-dark border-b border-gray-200 dark:border-gray-800 transition-colors duration-200">
        <div className="flex items-center px-4 py-3 justify-between relative">
          <Link to="/" className="flex items-center justify-center size-10 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors text-slate-900 dark:text-white relative z-10">
            <span className="material-symbols-outlined">arrow_back</span>
          </Link>
          <h2 className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-lg font-bold leading-tight tracking-tight text-center">
            Monatsprüfung
          </h2>
          <div className="flex items-center gap-2 relative z-10">
            <button className="flex items-center justify-center size-10 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors text-slate-500 dark:text-[#9dabb9]">
              <span className="material-symbols-outlined">filter_list</span>
            </button>
            <Link to="/" className="flex items-center justify-center size-10 rounded-full bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors" title="Abmelden">
              <span className="material-symbols-outlined">logout</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col p-4 gap-6 w-full pb-24">
        <section className="flex flex-col gap-2">
          <label className="text-sm font-medium text-slate-500 dark:text-slate-400">Zeitraum wählen</label>
          <div className="relative">
            <select 
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="appearance-none w-full bg-surface-light dark:bg-surface-dark border border-gray-200 dark:border-gray-700 text-slate-900 dark:text-white rounded-xl h-14 pl-12 pr-10 text-base font-medium focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-shadow"
            >
              <option value="oct-2023">Oktober 2023</option>
              <option value="sep-2023">September 2023</option>
              <option value="aug-2023">August 2023</option>
            </select>
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-primary pointer-events-none flex items-center">
              <span className="material-symbols-outlined">calendar_month</span>
            </div>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none flex items-center">
              <span className="material-symbols-outlined">expand_more</span>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-3 gap-3">
          <StatCard label="Diesel" value="12.450" unit="L" icon="local_gas_station" />
          <StatCard label="AdBlue" value="450" unit="L" icon="water_drop" />
          <StatCard label="Offen" value="3" unit="Einträge" icon="pending_actions" variant="primary" />
        </section>

        <div className="flex items-center justify-between pt-2">
          <h3 className="text-lg font-bold leading-tight tracking-tight text-slate-900 dark:text-white">Tägliche Einträge</h3>
          <button className="text-sm font-medium text-primary hover:text-primary/80">Alle anzeigen</button>
        </div>

        <div className="flex flex-col gap-4">
          {logs.map(log => (
            <LogCard key={log.id} log={log} />
          ))}
        </div>
      </main>

      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => navigate('/log-entry')}
          className="shadow-lg shadow-primary/30 flex items-center justify-center size-14 rounded-full bg-primary text-white hover:bg-primary/90 transition-transform hover:scale-105 active:scale-95"
        >
          <span className="material-symbols-outlined">add_task</span>
        </button>
      </div>
    </div>
  );
};

export default DashboardScreen;
