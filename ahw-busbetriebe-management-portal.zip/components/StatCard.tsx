
import React from 'react';

interface StatCardProps {
  label: string;
  value: string;
  unit: string;
  icon: string;
  variant?: 'default' | 'primary';
}

const StatCard: React.FC<StatCardProps> = ({ label, value, unit, icon, variant = 'default' }) => {
  const containerClass = variant === 'primary' 
    ? "bg-primary/10 border-primary/20" 
    : "bg-surface-light dark:bg-surface-dark border-gray-200 dark:border-gray-800 shadow-sm";
  
  const textClass = variant === 'primary' ? "text-primary" : "text-slate-500 dark:text-slate-400";
  const valueClass = variant === 'primary' ? "text-primary" : "text-slate-900 dark:text-white";

  return (
    <div className={`flex flex-col gap-1 rounded-xl p-3 border ${containerClass}`}>
      <div className={`flex items-center gap-1.5 ${textClass}`}>
        <span className="material-symbols-outlined text-lg">{icon}</span>
        <span className="text-[10px] font-semibold uppercase tracking-wide">{label}</span>
      </div>
      <p className={`text-xl font-bold tracking-tight ${valueClass}`}>
        {value} <span className={`text-[10px] font-medium ${variant === 'primary' ? 'text-primary/60' : 'text-slate-400'}`}>{unit}</span>
      </p>
    </div>
  );
};

export default StatCard;
