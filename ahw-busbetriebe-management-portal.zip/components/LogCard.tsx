
import React from 'react';
import { DailyLog, LogStatus } from '../types';
import { useNavigate } from 'react-router-dom';

interface LogCardProps {
  log: DailyLog;
}

const LogCard: React.FC<LogCardProps> = ({ log }) => {
  const navigate = useNavigate();

  const getStatusStyles = (status: LogStatus) => {
    switch (status) {
      case LogStatus.OPEN:
        return {
          border: 'border-l-yellow-500',
          badge: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
          icon: 'warning',
          text: 'Prüfung offen'
        };
      case LogStatus.OK:
        return {
          border: 'border-l-emerald-500',
          badge: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
          icon: 'check_circle',
          text: 'OK'
        };
      case LogStatus.DISCREPANCY:
        return {
          border: 'border-l-red-500',
          badge: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20',
          icon: 'priority_high',
          text: 'Abweichung'
        };
      default:
        return {
          border: 'border-l-gray-500',
          badge: 'bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20',
          icon: 'pending',
          text: 'Ausstehend'
        };
    }
  };

  const styles = getStatusStyles(log.status);

  return (
    <article className={`flex flex-col gap-3 p-4 rounded-xl bg-surface-light dark:bg-surface-dark border-l-4 ${styles.border} border-y border-r border-gray-200 dark:border-gray-800 shadow-sm relative overflow-hidden`}>
      <div className="flex justify-between items-start">
        <div className="flex flex-col">
          <span className="text-base font-bold text-slate-900 dark:text-white">{log.date}, {log.dayName}</span>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">{log.time} Uhr • {log.location}</span>
        </div>
        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${styles.badge} border`}>
          <span className="material-symbols-outlined text-[12px]">{styles.icon}</span>
          {styles.text}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2 py-2 border-y border-dashed border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-2">
          <div className="size-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
            <span className="material-symbols-outlined text-lg">directions_bus</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider">Wagen</span>
            <span className="text-xs font-bold text-slate-900 dark:text-white">{log.busId}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="size-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-slate-500 dark:text-slate-400">
            <span className="material-symbols-outlined text-lg">badge</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider">Fahrer</span>
            <span className="text-xs font-bold text-slate-900 dark:text-white">ID: {log.driverId}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2">
        <div className={`flex flex-col gap-1 items-start flex-1 p-2 rounded-lg ${log.status === LogStatus.DISCREPANCY ? 'bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30' : 'bg-gray-50 dark:bg-gray-800/50'}`}>
          <span className={`text-[9px] font-bold ${log.status === LogStatus.DISCREPANCY ? 'text-red-600 dark:text-red-400' : 'text-slate-500'} uppercase flex items-center gap-1`}>
            <span className="material-symbols-outlined text-[12px]">local_gas_station</span> Diesel
          </span>
          <span className={`text-xs font-bold ${log.status === LogStatus.DISCREPANCY ? 'text-red-700 dark:text-red-300' : 'text-slate-900 dark:text-white'}`}>{log.diesel} L</span>
        </div>
        <div className="flex flex-col gap-1 items-start flex-1 p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
          <span className="text-[9px] font-bold text-slate-500 uppercase flex items-center gap-1">
            <span className="material-symbols-outlined text-[12px]">water_drop</span> AdBlue
          </span>
          <span className="text-xs font-bold text-slate-900 dark:text-white">{log.adBlue} L</span>
        </div>
        <div className="flex flex-col gap-1 items-start flex-1 p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
          <span className="text-[9px] font-bold text-slate-500 uppercase flex items-center gap-1">
            <span className="material-symbols-outlined text-[12px]">oil_barrel</span> Öl
          </span>
          <span className="text-xs font-bold text-slate-900 dark:text-white">{log.oil ? `${log.oil} L` : '--'}</span>
        </div>
      </div>

      <div className="flex gap-3 mt-1">
        {log.status === LogStatus.OPEN ? (
          <>
            <button 
              onClick={() => navigate(`/log-entry/${log.id}`)}
              className="flex-1 h-10 flex items-center justify-center gap-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-slate-700 dark:text-slate-200 text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">edit</span>
              Bearbeiten
            </button>
            <button className="flex-1 h-10 flex items-center justify-center gap-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20">
              <span className="material-symbols-outlined text-[18px]">check</span>
              Bestätigen
            </button>
          </>
        ) : (
          <>
            <button 
              onClick={() => navigate(`/log-entry/${log.id}`)}
              className="flex-1 h-10 flex items-center justify-center gap-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-slate-700 dark:text-slate-200 text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">visibility</span>
              Details
            </button>
            <button className="flex-1 h-10 flex items-center justify-center gap-2 rounded-lg bg-white dark:bg-surface-dark border border-gray-200 dark:border-gray-700 text-slate-700 dark:text-white text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
              <span className="material-symbols-outlined text-[18px]">flag</span>
              Melden
            </button>
          </>
        )}
      </div>
    </article>
  );
};

export default LogCard;
